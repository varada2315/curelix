import { ArrowRight, CircleDot, Leaf, MessageCircleMore, PackageSearch } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Eyebrow, LinkButton, SectionHeading } from '../components/ContentBlocks.jsx';

const rangeAreas = [
  { no: '01', title: 'Nutrition supplements', icon: Leaf, text: 'A broad category at the heart of Curelix Lifesciences and its nutrition-first mission.' },
  { no: '02', title: 'Everyday wellbeing', icon: CircleDot, text: 'A starting point for conversations about nutrition and everyday wellness.' },
  { no: '03', title: 'Retailer & chemist connections', icon: PackageSearch, text: 'Connect with our team for current product details, availability and channel enquiries.' },
];

export default function RangePage() {
  return (
    <>
      <section className="page-hero section-wrap range-hero">
        <div className="page-hero-copy">
          <Eyebrow>NUTRACEUTICAL FOCUS</Eyebrow>
          <h1>Nutrition,<br /><em>with purpose.</em></h1>
          <p>Our focus is a strong range of nutraceuticals — guided by our aim to make best-in-class nutrition supplements part of a healthier India.</p>
          <div className="page-hero-actions"><LinkButton to="/contact">Ask about our range</LinkButton><span className="caption-note">Information from our team, not a catalogue.</span></div>
          <div className="page-hero-meta"><span>02</span><i /><span>OUR NUTRACEUTICAL FOCUS</span></div>
        </div>
        <div className="range-hero-art" aria-hidden="true">
          <div className="range-hero-surface" />
          <div className="range-hero-glass glass-one" /><div className="range-hero-glass glass-two" /><div className="range-hero-glass glass-three" />
          <div className="range-hero-orbit"><span /><span /><span /></div>
          <div className="range-hero-label"><span>01</span><i /> A thoughtful<br />nutrition focus</div>
          <div className="range-hero-stamp"><Leaf size={21} /><small>PEOPLE<br />FIRST</small></div>
        </div>
      </section>

      <section className="range-overview section-wrap">
        <SectionHeading eyebrow="RANGE OVERVIEW" title={<>A clear starting point.<br /><em>Personal answers.</em></>} body="We share a category-level overview here. Product names, formulations, availability and other specifics should be confirmed directly with the Curelix Lifesciences team." />
        <div className="range-area-list">
          {rangeAreas.map(({ no, title, icon: Icon, text }) => (
            <article className="range-area-card" key={no}>
              <span className="range-area-no">{no}</span>
              <div className="range-area-icon"><Icon size={20} strokeWidth={1.7} /></div>
              <div className="range-area-content"><h3>{title}</h3><p>{text}</p></div>
              <Link to="/contact" className="range-area-link" aria-label={`Ask about ${title}`}><ArrowRight size={17} /></Link>
            </article>
          ))}
        </div>
        <div className="range-disclosure"><span className="disclosure-mark">i</span><p><strong>A note on product information</strong><br />This page is not a product catalogue. No specific product brands, ingredients, certifications, or medical benefits are being represented here. Please speak with our team for verified, up-to-date product information.</p></div>
      </section>

      <section className="range-partner-section">
        <div className="section-wrap partner-inner">
          <div className="partner-symbol"><MessageCircleMore size={25} /></div>
          <div className="partner-copy"><Eyebrow light>FOR RETAILERS &amp; CHEMISTS</Eyebrow><h2>Let's talk about<br /><em>working together.</em></h2><p>Connect with Curelix Lifesciences to ask about the current range and partnership enquiries.</p></div>
          <LinkButton to="/contact" variant="light">Start a conversation</LinkButton>
        </div>
      </section>

      <section className="range-patient-note section-wrap"><span className="patient-note-icon"><CircleDot size={18} /></span><p><strong>For patients:</strong> Product selection and health decisions are personal. Please consult a qualified healthcare professional for advice suited to your needs.</p></section>
    </>
  );
}
